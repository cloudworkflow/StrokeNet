from .ftml import FTML
from .padam import Padam

# aliases
ftml = FTML
